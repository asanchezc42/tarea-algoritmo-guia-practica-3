# Tarea de Fundamentos - Algoritmos en JavaScript

Este proyecto contiene:
- bloque1.js → Ejercicios individuales
- bloque2.js → Ejercicios con listas

Listo para subir a GitHub.
