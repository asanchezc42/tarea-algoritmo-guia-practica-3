// BLOQUE 1 - Ejercicios individuales
// Código en JavaScript

// 1. Fibonacci
let n = parseInt(prompt("Ingresa n: "));
let a = 0;
let b = 1;
let serie = a + "\n" + b + "\n";
for (let i = 2; i < n; i++) {
    let c = a + b;
    serie = serie + c + "\n";
    a = b;
    b = c;
}
console.log(serie);

// ... (otros ejercicios irían aquí)
