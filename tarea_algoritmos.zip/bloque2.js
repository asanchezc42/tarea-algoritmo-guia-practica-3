// BLOQUE 2 - Ejercicios con listas
// Código en JavaScript

let lista = [5, 8, 10];
let salida = "";

for (let x = 0; x < lista.length; x++) {
    let n = lista[x];
    let a = 0;
    let b = 1;
    let serie = a + " " + b + " ";
    for (let i = 2; i < n; i++) {
        let c = a + b;
        serie = serie + c + " ";
        a = b;
        b = c;
    }
    salida = salida + "Fibonacci(" + n + "): " + serie + "\n";
}
console.log(salida);
